## ** What is Markdown**
Markdown is a content focus Markup language created by John Gruber in 2004; Markdown lets you write plain text documents with a few lightweight formatting options.

## ** What is GIT**
Git is a version control system that runs on your local machine that tracks every change to your code that is made.

## ** What is GitHub**
GitHub is basically Git hosted on the web or cloud, it is a team development that can allow developer to work on the same code at the same time without conflicting with each other.

## ** What is Slack**
Slack is a business messaging and collaboration app similar to discord that is mainly used in a business/professional environment.